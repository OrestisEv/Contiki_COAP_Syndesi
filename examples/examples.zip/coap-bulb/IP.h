Name					Function				ID					IP
------------|	-----------|		--------|		----------------------
BorderRouter															aaaa:0000:0000:0000:0212:7400:1465:d943

Room1					Door						C1					aaaa:0000:0000:0000:0212:7400:1465:c051

Orestis				Bulb						C1S7A1			aaaa:0000:0000:0000:0212:7400:1465:c6db
Orestis				Curtain					C1S7A2			aaaa:0000:0000:0000:0212:7400:1465:6184
Orestis				Alarm						C1S7A3			aaaa:0000:0000:0000:0212:7400:1465:d12f
Orestis				Coffee					C1S7A4			aaaa:0000:0000:0000:0212:7400:1465:d268
Cristina			Bulb						C1S4A1			aaaa:0000:0000:0000:0212:7400:1465:ce49
Pierre				Bulb						C1S1A1			aaaa:0000:0000:0000:0212:7400:117b:bb79
Pierre				Fan							C1S1A2			aaaa:0000:0000:0000:0212:7400:1465:dad1
Tigran				Bulb						C1S2A1			aaaa:0000:0000:0000:0212:7400:1465:c08e



useful: 

ls -l /dev/
sudo chmod o+rw /dev/ttyUSB1

