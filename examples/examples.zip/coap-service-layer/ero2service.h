/**
* \file
* 		ErO2 Manager which implements the services exposed by the individual devices
* \author
* 		Kasun Samarasinghe <Kasun.Wijesiriwardana@unige.ch>
*/
#ifndef ERO2MANAGER_H_
#define ERO2MANAGER_H_

void start_app_services();

#endif
